#!/bin/bash
set -e
./run.sh --tests $@
