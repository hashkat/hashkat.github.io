/*
 * tests.h:
 *  Main header for unit tests. Provides convenience methods.
 */

#ifndef TESTS_H_
#define TESTS_H_

#include <dependencies/UnitTest++.h>

#endif
